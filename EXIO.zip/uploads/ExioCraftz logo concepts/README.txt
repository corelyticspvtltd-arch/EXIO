ExioCraftz — Concept 1A "Bracket Craft"
Tagline: Your vision, our crafted code.

/svg  — vector, infinitely scalable
  mark-black / mark-white ................ symbol only (app icon, favicon, avatar)
  lockup-horizontal-* .................... symbol + wordmark
  lockup-tagline-* ....................... stacked, with tagline
/png  — raster exports at 2x (transparent-free, flat backgrounds)

TYPEFACES
  Wordmark : Sora — 600 (Exio) + 200 (Craftz), tracking -0.025em
  Tagline  : IBM Plex Mono 400, uppercase, tracking 0.18em
  Both free on Google Fonts. The SVG lockups reference Sora by name; install
  the font, or use the PNG versions where type is already rendered.

COLOR
  Ink    #0A0A0A      Paper  #FCFCFB
  Never place the mark on a background below 4.5:1 contrast.

CLEAR SPACE
  Keep free space equal to the height of one E-bar (1/8 of mark height) on all sides.
  Minimum mark size: 16px digital / 6mm print. Below that use the mark alone, never the lockup.
